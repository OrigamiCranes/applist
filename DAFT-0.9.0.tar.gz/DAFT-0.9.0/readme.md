### DAFT: Database Audit Framework & Toolkit ### 
This is a C# port of <a href="  https://github.com/NetSPI/PowerUpSQL/wiki">PowerUpSQL</a>.
